# WA OneSecond Visual Demo

Standalone Android WebView application with a custom dark/red theme and supplied background image. It is a UI simulation only. It does not access WhatsApp servers, does not check bans, and does not impersonate an official WhatsApp app.

## Build
Use GitHub Actions workflow `.github/workflows/build-apk.yml` with manual trigger. APK artifact will be uploaded as `WA-OneSecond-Demo-APK`.
