# OneSecond Demo Android

Standalone Android WebView demo. The number status is simulated; it does not connect to WhatsApp or check real account bans.

## Build using GitHub Actions
1. Upload this project folder's contents to a new GitHub repository (keep `.github/workflows/build-apk.yml`).
2. Open **Actions** → **Build OneSecond APK** → **Run workflow**.
3. Download `OneSecond-Demo-APK` from the run's Artifacts.

Requirements for local build: JDK 17, Android SDK platform 35, Build Tools 35.0.0, Gradle 8.7.
